// pair game
// mining game
// Date
//
// Extra for Experts:
// - describe what you did to take this project "above and beyond"
 


// global variables
let space = [];
let moved = 0;
let coins = 0;
let breake = 0;

function setup() {
	createCanvas(800, 600);
	for (let x = 0; x < 76; x++) {
		space[x] = [];
		for (let y = 0; y < 40; y++) {
			if (y < 6) {
				space[x][y] = 0;
			} else {
				if (random(0, 1) > 0.85) {
					if (random(0, 1) > 0.7) {
						if (random(0, 1) > 0.8) {
							if (random(0, 1) > 0.75) {
								space[x][y] = 5;
							} else {
								space[x][y] = 4;
							}
						} else {
							space[x][y] = 3;
						}
					} else {
						space[x][y] = 2;
					}
				} else {
					space[x][y] = 1;
				}
			}
			if (x === 2 && y === 5) {
				space[x][y] = -1;
			}
		}
	}
}

function draw() {
	moved -= 1;
	background(255);
	for (let x = 0; x < 76; x += 1) {
		for (let y = 0; y < 40; y += 1) {
			noStroke();
			if (space[x][y] === -1) {
				if (keyIsDown(LEFT_ARROW) && moved < 0 && x > 0) {
					if (space[x - 1][y] === 2) {
						coins++
					}
					if (space[x - 1][y] === 3) {
						coins += 3
					}
					if (space[x - 1][y] === 4) {
						coins += 10
					}
					if (space[x - 1][y] === 5) {
						coins += 25
					}
					space[x][y] = 0
					space[x - 1][y] = -1
					moved = 1
					breake++
					fill(255)
					rect(x * 25, y * 25, 50, 50);
				}
				if (keyIsDown(RIGHT_ARROW) && moved < 0 && x < 75) {
					if (space[x + 1][y] === 2) {
						coins++
					}
					if (space[x + 1][y] === 3) {
						coins += 3
					}
					if (space[x + 1][y] === 4) {
						coins += 10
					}
					if (space[x + 1][y] === 5) {
						coins += 25
					}
					space[x][y] = 0
					space[x + 1][y] = -1
					moved = 1
					breake++
				}
				if (keyIsDown(UP_ARROW) && moved < 0 && y > 5) {
					if (space[x][y - 1] === 2) {
						coins++
					}
					if (space[x][y - 1] === 3) {
						coins += 3
					}
					if (space[x][y - 1] === 4) {
						coins += 10
					}
					if (space[x][y - 1] === 5) {
						coins += 25
					}
					space[x][y] = 0
					space[x][y - 1] = -1
					moved = 1
					breake++
					fill(255)
					rect(x * 25, y * 25, 50, 50);
				}
				if (keyIsDown(DOWN_ARROW) && moved < 0 && y < 39) {
					if (space[x][y + 1] === 2) {
						coins++
					}
					if (space[x][y + 1] === 3) {
						coins += 3
					}
					if (space[x][y + 1] === 4) {
						coins += 10
					}
					if (space[x][y + 1] === 5) {
						coins += 25
					}
					space[x][y] = 0
					space[x][y + 1] = -1
					moved = 1
					breake++
				}
				if (space[x][y] === -1) {
					fill(255)
					rect(x * 25, y * 25, 50, 50);
				}
			}
      else if (space[x][y] === 0) {
				fill(0, 200, 250)
				rect(x * 25, y * 25, 50, 50);
			} else if (space[x][y] === 1) {
				fill(140)
				rect(x * 25, y * 25, 50, 50);
			} else if (space[x][y] === 2) {
				fill(140)
				rect(x * 25, y * 25, 50, 50);
				fill(0)
				ellipse(x * 25 + 5, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
				ellipse(x * 25 + 5, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 20, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 10, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
			} else if (space[x][y] === 3) {
				fill(140)
				rect(x * 25, y * 25, 50, 50);
				fill(180, 100, 0)
				ellipse(x * 25 + 5, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
				ellipse(x * 25 + 5, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 20, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 10, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
			} else if (space[x][y] === 4) {
				fill(140)
				rect(x * 25, y * 25, 50, 50);
				fill(250, 250, 0)
				ellipse(x * 25 + 5, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
				ellipse(x * 25 + 5, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 20, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 10, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
			} else if (space[x][y] === 5) {
				fill(140)
				rect(x * 25, y * 25, 50, 50);
				fill(150, 250, 250)
				ellipse(x * 25 + 5, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
				ellipse(x * 25 + 5, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 20, 5, 5)
				ellipse(x * 25 + 20, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 10, y * 25 + 15, 5, 5)
				ellipse(x * 25 + 15, y * 25 + 5, 5, 5)
			}
		}
	}
	stroke(0)
	fill(0)
	textSize(30)
	text(coins, 20, 40)
	if (breake > 500) {
		for (let x = 0; x < 38; x++) {
			space[x] = [];
			for (let y = 0; y < 40; y++) {
				if (y < 6) {
					space[x][y] = 0
				} else {
					if (random(0, 1) > 0.9) {
						if (random(0, 1) > 0.7) {
							if (random(0, 1) > 0.8) {
								space[x][y] = 4
							} else {
								space[x][y] = 3
							}
						} else {
							space[x][y] = 2
						}
					} else {
						space[x][y] = 1
					}
				}
				if (x === 9 && y === 5) {
					space[x][y] = -1
				}
			}
		}
		breake = 0
	}
}
